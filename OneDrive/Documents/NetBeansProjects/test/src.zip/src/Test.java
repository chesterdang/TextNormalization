
import controller.NormalizingProgramming;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author danhv
 */
public class Test {
    public static void main(String[] args) {
        NormalizingProgramming programming = new NormalizingProgramming();
        programming.run();
    }
}
